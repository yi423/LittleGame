﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    private Rigidbody2D heroBody;
    public float force=3;
    // Start is called before the first frame update

    void Start()
    {
      heroBody =  this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        Vector2 vector2 = transform.position;
        vector2.x = vector2.x +force*h*Time.deltaTime;
        //transform.position = vector2;
        heroBody.MovePosition(vector2);
        
    }
}
